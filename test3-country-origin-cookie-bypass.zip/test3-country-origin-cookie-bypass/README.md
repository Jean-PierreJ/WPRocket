﻿# WP Rocket | Use different cache version depending on visitor's country of origin; Save country in cookie

A WP Rocket customer is displaying different content depending on the country of origin of its visitors, so he wants a different cache version based on the country. The country is saved as a cookie in the visitor browser, with the name origin_country.

Using WP Rocket hooks, prevent serving the cache until a cookie named origin_country is set on the visitor browser.
Using WP Rocket hooks, serve the corresponding cache version based on the value of the origin_country cookie.

This should be done by creating a plugin/mu-plugin

Documentation:
* [Disable page caching](https://docs.wp-rocket.me/article/142-how-to-make-a-custom-mu-plugin)
* [Get visitor country from their IP](https://ourcodeworld.com/articles/read/51/how-to-detect-the-country-of-a-visitor-in-php-or-javascript-for-free-with-the-request-ip)
* [Call the function from geotargetingwp.php](https://wordpress.stackexchange.com/questions/73047/how-to-call-a-plugin-function-from-index-php)

To be used with:
* any setup

Dev Notes:
* I used https://github.com/wp-media/wp-rocket-helpers/tree/master/cache/wp-rocket-no-cache/ as the basis for the code, modifying it slightly to suit the needs.
* The code begins by the included plugin security from the mu plugin code.
*
* Next I create a function to set the cookie to the country code.
* This uses code from an ourcodeworld.com article (see above) to check the visitor's IP address against JSON running on geoplugin.net
* This then dumps the information returned into a custom data array
* Next a cookie is created, called origin_country, and the country code from the data array is stored in the cookie
* Finally, the function defines a cookie called cookies, which duplicates the data
* This is where I think it starts to become messy, and I think it would be simpler to omit the first cookie and just use this one.
* The reason I did not do this is simply because the instructions were to use the cookie called origin_country
* I'm not clear as to whether the Geotargeting WP plugin could use this name, which is why I entered in both and essentially duplicated the data. 
*
* After the function, an action is added prior to checking to see if the function "rocket_activate_geotargetingwp()" is active.
* This final if statement notifies the user in this case that they cannot use this plugin without first installing and activating the geotargeting WP plugin.
*
* This was used as I was unable to find anything in the documentation itself about either Geotracking or multiple cache versions
* The closest I could find in the docs were about WooCommerce, and it wasn't clear that this was being used for ecommerce (it could be used for other things like GDPR)
* I was unsure of whether AWS or Cloudflare could be used to suit this and, as my first attempt at something like this, I wanted to provide a solution that should work
* After searching the WP Rocket source code, I found mention of WooCommerce again, as well as language options in WP Rocket and Geotracking
* Looking into the functions involved, this seemed to be the better option given how I understood the intent of the task