<?php
/**
 * Plugin Name: country-origin-change-cache-version
 * Description: Display different content depending on the country of origin of its visitors using a different cache version based on the country. 
 *              The country is saved as a cookie in the visitor browser, with the name origin_country.
 * Author:      Jean-Pierre Joubert
 * License:     GNU General Public License v3 or later
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * Copied from URL: https://docs.wp-rocket.me/article/142-how-to-make-a-custom-mu-plugin
 */

// Basic security, prevents file from being loaded directly.
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );


function set_cookie_to_country_code() {
	/**
	 * Description: Get visitor country from their IP
	 * @URL https://ourcodeworld.com/articles/read/51/how-to-detect-the-country-of-a-visitor-in-php-or-javascript-for-free-with-the-request-ip
	 * You can use a more sophisticated method to retrieve the content of a webpage with php using a library or something
	 * We will retrieve quickly with the file_get_contents
	 * outputs something like (obviously with the data of your IP) :
	 * geoplugin_countryCode => "DE",
	 * geoplugin_countryName => "Germany"
	 * geoplugin_continentCode => "EU"
	 */
	$ip = $_SERVER['REMOTE_ADDR']; // This will contain the ip of the request
	$dataArray = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));
	var_dump($dataArray);

	/**
	 * Create and set the cookie named origin_country based on dataArray set in previous step
	 * Also create cookie named cookies and set it to origin_country (this is passed to external plugin
	 */
	$cookie_name = "origin_country"; // create cookie called origin_country
	$cookie_value = .$dataArray["geoplugin_countryCode"]; // set cookie value to equal the geoplugin_countryCode
	setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day

	/** 
	 * this is required by the Geotargeting WP plugin to designate a unique, country-specific cache
	 */
	$cookie_name = "cookies"; // create new cookie called "cookies"
	$cookie_value = .$origin_country[""]; // set cookie 
	setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day
}

// add action

add_action( 'set_cookie_to_country_code', 'rocket_activate_geotargetingwp' );

/**
 * Call the function from geotargetingwp.php
 * Requires the Geotargeting WP plugin in order to work
 * https://wordpress.stackexchange.com/questions/73047/how-to-call-a-plugin-function-from-index-php
 */

if(function_exists('rocket_activate_geotargetingwp()')){
	rocket_activate_geotargetingwp();
} else {
    echo "oh dear you haven't activated/installed 'getargetingwp', go do that before the 'rocket_activate_geotargetingwp()' feature is available";
}