﻿# WP Rocket | Disable Caching for Administrators Only

A WP Rocket customer is using the user cache option to provide the cache to logged-in users. But he would like to prevent caching for administrators.

By creating a plugin/mu-plugin, disable caching for administrators only.
WP Rocket detects the DONOTCACHEPAGE constant value to determine if the current page should be cached

Documentation:
* https://docs.wp-rocket.me/article/919-disable-cache-for-logged-in-administrators
* https://docs.wp-rocket.me/article/142-how-to-make-a-custom-mu-plugin

To be used with:
* any setup

Dev Notes:
* I used code found on https://docs.wp-rocket.me/article/142-how-to-make-a-custom-mu-plugin as the basis for the code.
* In addition I liberally used code from https://github.com/wp-media/wp-rocket-helpers/raw/master/cache/wp-rocket-no-cache-for-admins/wp-rocket-no-cache-for-admins.zip
*
* The code begins by defining a namespace, followed by defacto plugin security.
* It then disables caching for admins, checking first to see if the user is (a) logged in and then (b) if they are an admin user
* If either of those conditions are not true, it returns false; If true it adds an action to the namespace.
* Next another action is added to handle the admin cache.
* Finally, a function called donotcache() has been created that conditionally checks to see if DONOTCACHEPAGE and DONOTROCKETOPTIMIZE exist.
* If they do not, it defines each in turn, and sets them to "true"
* If they do exist, they function returns "true"
*
* If I were asked this question by a customer, to be honest I would probably give them the link rather than code my own.
* The reasons are:
* 1. It's much faster and gets them moving forward quicker
* 2. The pre-existing solution is far more elegant as it includes checks to ensure less points of failure
* 3. It also provides a notification so that admin users can see visually when the cache has been disabled for them
* 4. It has been tested and proven to work where this has not.