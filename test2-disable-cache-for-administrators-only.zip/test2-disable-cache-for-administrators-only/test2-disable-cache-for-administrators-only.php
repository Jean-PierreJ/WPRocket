<?php
/**
 * Plugin Name: test2-disable-cache-for-administrators-only
 * Description: Use the user cache option to provide the cache to logged-in users, while preventing caching for administrators
 * WP Rocket should detect the DONOTCACHEPAGE constant value to determine if the current page should be cached
 * Author:      Jean-Pierre Joubert
 * License:     GNU General Public License v3 or later
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * Copied from URL: https://docs.wp-rocket.me/article/142-how-to-make-a-custom-mu-plugin
 * Also includes code from 
 */

namespace WP_Rocket\Helpers\cache\no_cache_for_admins;

// Basic security, prevents file from being loaded directly.
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

/* 
 * Create function to call when disabling cache for admins
 * Contains code plugin available on https://docs.wp-rocket.me/article/919-disable-cache-for-logged-in-administrators
 */

function disable_wp_rocket_cache_for_admins() {
	
	// check if users logged in
	if ( ! get_rocket_option( 'cache_logged_user' ) ) {
		return false;
	}
	
	// check if user is admin
	if ( ! current_user_can( 'administrator' ) ) {
		return false;
		
	// Finally: prevent caching for administrators.
	add_action( 'template_redirect', __NAMESPACE__ . '\donotcache' );

	return true;
}	


/**
 * Pass your custom function to the wp_rocket_loaded action hook.
 *
 * Note: wp_rocket_loaded itself is hooked into WordPress� own
 * plugins_loaded hook.
 * Depending what kind of functionality your custom plugin
 * should implement, you can/should hook your function(s) into
 * different action hooks, such as for example
 * init, after_setup_theme, or template_redirect.
 * 
 * Learn more about WordPress actions and filters here:
 * https://developer.wordpress.org/plugins/hooks/
 *
 * @param string 'wp_rocket_loaded'         Hook name to hook function into
 * @param string 'yourprefix__do_something' Function name to be hooked
 */
add_action( 'init', __NAMESPACE__ . '\handle_cache_for_admins' );

/**
 * Prevent caching and optimization.
 *
 * @author Caspar H�binger
 *
 * Borrowed from plugin available on https://docs.wp-rocket.me/article/919-disable-cache-for-logged-in-administrators
 */
function donotcache() {

	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	
	if ( ! defined( 'DONOTROCKETOPTIMIZE' ) ) {
		define( 'DONOTROCKETOPTIMIZE', true );
	}
	
	return true;
}