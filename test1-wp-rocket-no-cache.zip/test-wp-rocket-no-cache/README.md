﻿# WP Rocket | Disable Page Caching

Disables WP Rocket’s page cache while preserving other optimization features.

Documentation:
* [Disable page caching](http://docs.wp-rocket.me/article/61-disable-page-caching)

To be used with:
* any setup

Dev Notes:
* I used https://github.com/wp-media/wp-rocket-helpers/tree/master/cache/wp-rocket-no-cache/ as the basis for the code, modifying it slightly to suit the needs.
* All original comments and authorship has been left intact for the most part to ensure attribution
* The code begins by defining a namespace, followed by defacto plugin security.
* It then disables caching through filtering, before conditionally hooking into WP Rocket in order to purge the cache.
* Next there is a condition to clean the entire cache folder if the function rocket_clean_domain doesn't exist.
* Finally, there is an activation hook.